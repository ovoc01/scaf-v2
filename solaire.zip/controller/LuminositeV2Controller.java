package com.noarthedev.panneau.controller;

import com.framework.annotation.*;
import com.framework.ModelView;
import com.noarthedev.panneau.entity.LuminositeV2;



public class LuminositeV2Controller extends LuminositeV2 {
    
    

    @restAPI
    @RequestBody
    @url(value = "luminositeV2s.do", method = "POST", error = "error.do")
    public void insert() throws Exception{
        this.insert(null);
    }



    @restAPI
    @url(value = "luminositeV2s.do",method = "GET", errpr = "error.do")
    public ModelView findAll() throws Exception{
        ModelView view = new ModelView();
        view.addItem("luminositeV2s",this.findAll(null));
        return view;
    }

    @restAPI
    @RequestBody
    @url(value = "luminositeV2s.do",method = "PUT", error = "error.do")
    public void update() throws Exception{
        this.update(null);
    }





}