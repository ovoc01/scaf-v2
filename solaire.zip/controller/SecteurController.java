package com.noarthedev.panneau.controller;

import com.framework.annotation.*;
import com.framework.ModelView;
import com.noarthedev.panneau.entity.Secteur;



public class SecteurController extends Secteur {
    
    

    @restAPI
    @RequestBody
    @url(value = "secteurs.do", method = "POST", error = "error.do")
    public void insert() throws Exception{
        this.insert(null);
    }



    @restAPI
    @url(value = "secteurs.do",method = "GET", errpr = "error.do")
    public ModelView findAll() throws Exception{
        ModelView view = new ModelView();
        view.addItem("secteurs",this.findAll(null));
        return view;
    }

    @restAPI
    @RequestBody
    @url(value = "secteurs.do",method = "PUT", error = "error.do")
    public void update() throws Exception{
        this.update(null);
    }





}