package com.noarthedev.panneau.controller;

import com.framework.annotation.*;
import com.framework.ModelView;
import com.noarthedev.panneau.entity.Luminosite;



public class LuminositeController extends Luminosite {
    
    

    @restAPI
    @RequestBody
    @url(value = "luminosites.do", method = "POST", error = "error.do")
    public void insert() throws Exception{
        this.insert(null);
    }



    @restAPI
    @url(value = "luminosites.do",method = "GET", errpr = "error.do")
    public ModelView findAll() throws Exception{
        ModelView view = new ModelView();
        view.addItem("luminosites",this.findAll(null));
        return view;
    }

    @restAPI
    @RequestBody
    @url(value = "luminosites.do",method = "PUT", error = "error.do")
    public void update() throws Exception{
        this.update(null);
    }





}