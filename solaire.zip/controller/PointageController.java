package com.noarthedev.panneau.controller;

import com.framework.annotation.*;
import com.framework.ModelView;
import com.noarthedev.panneau.entity.Pointage;



public class PointageController extends Pointage {
    
    

    @restAPI
    @RequestBody
    @url(value = "pointages.do", method = "POST", error = "error.do")
    public void insert() throws Exception{
        this.insert(null);
    }



    @restAPI
    @url(value = "pointages.do",method = "GET", errpr = "error.do")
    public ModelView findAll() throws Exception{
        ModelView view = new ModelView();
        view.addItem("pointages",this.findAll(null));
        return view;
    }

    @restAPI
    @RequestBody
    @url(value = "pointages.do",method = "PUT", error = "error.do")
    public void update() throws Exception{
        this.update(null);
    }





}