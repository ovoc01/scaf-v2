package com.noarthedev.panneau.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.noarthedev.panneau.entity.SourceEnergie;
import com.noarthedev.panneau.repository.SourceEnergieRepository;

@Service

public class SourceEnergieService  {
   @Autowired
   SourceEnergieRepository sourceEnergieRepository;

   
   public List<SourceEnergie> getAllEntities() {
        return sourceEnergieRepository.findAll();
    }


    public Optional<SourceEnergie> getEntityById(String id) {
        return sourceEnergieRepository.findById(id);
    }


    public SourceEnergie saveEntity(EntityName entityName) {
        return sourceEnergieRepository.save(entityName);
    }


    public SourceEnergie updateEntity(SourceEnergie sourceEnergie) {
        return sourceEnergieRepository.save(sourceEnergie);
    }

    public void deleteEntityById(String id) {
        sourceEnergieRepository.deleteById(id);
    }



}