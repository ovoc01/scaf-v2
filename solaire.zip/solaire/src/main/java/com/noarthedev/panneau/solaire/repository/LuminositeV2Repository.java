package com.noarthedev.panneau.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.noarthedev.panneau.entity.LuminositeV2;

@Repository

public class LuminositeV2Repository extends JpaRepository<LuminositeV2,String> {

}