package com.noarthedev.panneau.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.noarthedev.panneau.entity.Coupure;

@Repository

public class CoupureRepository extends JpaRepository<Coupure,String> {

}