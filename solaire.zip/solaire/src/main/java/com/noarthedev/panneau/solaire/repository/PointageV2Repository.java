package com.noarthedev.panneau.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.noarthedev.panneau.entity.PointageV2;

@Repository

public class PointageV2Repository extends JpaRepository<PointageV2,String> {

}