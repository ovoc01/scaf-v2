package com.noarthedev.panneau.entity;

import com.connection.database.BddObject;


public class Batterie extends BddObject {

    
    String idBatterie;

    
    Double capacite;

    
    public Batterie (){
        setTable("batterie");
        setConnection("PostgreSQL");
        setPrefix("CLA");
        setPrimaryKeyName("id_batterie")
        setFunctionPK("next_val('seq_batterie'")
        setCountPK(7);
    }


    
    public void setIdBatterie(String idBatterie){
        this.idBatterie = idBatterie;
    }

    public String getIdBatterie(){
        return this.idBatterie;
    }


    public void setCapacite(Double capacite){
        this.capacite = capacite;
    }

    public Double getCapacite(){
        return this.capacite;
    }



}