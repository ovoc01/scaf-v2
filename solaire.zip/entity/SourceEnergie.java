package com.noarthedev.panneau.entity;

import com.connection.database.BddObject;


public class SourceEnergie extends BddObject {

    
    String idSource;

    
    String idSecteur;
    
    String idPanneau;

    
    public SourceEnergie (){
        setTable("sourceEnergie");
        setConnection("PostgreSQL");
        setPrefix("CLA");
        setPrimaryKeyName("id_source");
        setFunctionPK("next_val('seq_sourceEnergie'");
        setCountPK(7);
    }


    
    public void setIdSource(String idSource){
        this.idSource = idSource;
    }

    public String getIdSource(){
        return this.idSource;
    }


    public void setIdSecteur(String idSecteur){
        this.idSecteur = idSecteur;
    }

    public String getIdSecteur(){
        return this.idSecteur;
    }


    public void setIdPanneau(String idPanneau){
        this.idPanneau = idPanneau;
    }

    public String getIdPanneau(){
        return this.idPanneau;
    }



}