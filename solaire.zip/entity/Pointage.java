package com.noarthedev.panneau.entity;

import com.connection.database.BddObject;
import java.sql.Date;
import java.sql.Time;


public class Pointage extends BddObject {

    
    String idPointage;

    
    String idSalle;
    
    Date date;
    
    Time heureDebut;
    
    Time heureFin;
    
    Integer nbrEtudiant;

    
    public Pointage (){
        setTable("pointage");
        setConnection("PostgreSQL");
        setPrefix("CLA");
        setPrimaryKeyName("id_pointage");
        setFunctionPK("next_val('seq_pointage'");
        setCountPK(7);
    }


    
    public void setIdPointage(String idPointage){
        this.idPointage = idPointage;
    }

    public String getIdPointage(){
        return this.idPointage;
    }


    public void setIdSalle(String idSalle){
        this.idSalle = idSalle;
    }

    public String getIdSalle(){
        return this.idSalle;
    }


    public void setDate(Date date){
        this.date = date;
    }

    public Date getDate(){
        return this.date;
    }


    public void setHeureDebut(Time heureDebut){
        this.heureDebut = heureDebut;
    }

    public Time getHeureDebut(){
        return this.heureDebut;
    }


    public void setHeureFin(Time heureFin){
        this.heureFin = heureFin;
    }

    public Time getHeureFin(){
        return this.heureFin;
    }


    public void setNbrEtudiant(Integer nbrEtudiant){
        this.nbrEtudiant = nbrEtudiant;
    }

    public Integer getNbrEtudiant(){
        return this.nbrEtudiant;
    }



}