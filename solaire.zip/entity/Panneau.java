package com.noarthedev.panneau.entity;

import com.connection.database.BddObject;


public class Panneau extends BddObject {

    
    String idPanneau;

    
    Double puissanceMax;
    
    String idBatterie;

    
    public Panneau (){
        setTable("panneau");
        setConnection("PostgreSQL");
        setPrefix("CLA");
        setPrimaryKeyName("id_panneau")
        setFunctionPK("next_val('seq_panneau'")
        setCountPK(7);
    }


    
    public void setIdPanneau(String idPanneau){
        this.idPanneau = idPanneau;
    }

    public String getIdPanneau(){
        return this.idPanneau;
    }


    public void setPuissanceMax(Double puissanceMax){
        this.puissanceMax = puissanceMax;
    }

    public Double getPuissanceMax(){
        return this.puissanceMax;
    }


    public void setIdBatterie(String idBatterie){
        this.idBatterie = idBatterie;
    }

    public String getIdBatterie(){
        return this.idBatterie;
    }



}