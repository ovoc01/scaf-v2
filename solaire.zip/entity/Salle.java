package com.noarthedev.panneau.entity;

import com.connection.database.BddObject;


public class Salle extends BddObject {

    
    String idSalle;

    
    String libelle;
    
    String idSecteur;

    
    public Salle (){
        setTable("salle");
        setConnection("PostgreSQL");
        setPrefix("CLA");
        setPrimaryKeyName("id_salle");
        setFunctionPK("next_val('seq_salle'");
        setCountPK(7);
    }


    
    public void setIdSalle(String idSalle){
        this.idSalle = idSalle;
    }

    public String getIdSalle(){
        return this.idSalle;
    }


    public void setLibelle(String libelle){
        this.libelle = libelle;
    }

    public String getLibelle(){
        return this.libelle;
    }


    public void setIdSecteur(String idSecteur){
        this.idSecteur = idSecteur;
    }

    public String getIdSecteur(){
        return this.idSecteur;
    }



}