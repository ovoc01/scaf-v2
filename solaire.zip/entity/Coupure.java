package com.noarthedev.panneau.entity;

import com.connection.database.BddObject;


public class Coupure extends BddObject {

    
    String idCoupure;

    
    String idSecteur;
    
    Date date;
    
    Time heureDebut;

    
    public Coupure (){
        setTable("coupure");
        setConnection("PostgreSQL");
        setPrefix("CLA");
        setPrimaryKeyName("id_coupure")
        setFunctionPK("next_val('seq_coupure'")
        setCountPK(7);
    }


    
    public void setIdCoupure(String idCoupure){
        this.idCoupure = idCoupure;
    }

    public String getIdCoupure(){
        return this.idCoupure;
    }


    public void setIdSecteur(String idSecteur){
        this.idSecteur = idSecteur;
    }

    public String getIdSecteur(){
        return this.idSecteur;
    }


    public void setDate(Date date){
        this.date = date;
    }

    public Date getDate(){
        return this.date;
    }


    public void setHeureDebut(Time heureDebut){
        this.heureDebut = heureDebut;
    }

    public Time getHeureDebut(){
        return this.heureDebut;
    }



}