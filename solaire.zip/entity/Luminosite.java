package com.noarthedev.panneau.entity;

import com.connection.database.BddObject;
import java.sql.Date;
import java.sql.Time;


public class Luminosite extends BddObject {

    
    String idLuminosite;

    
    Date date;
    
    Time heureDebut;
    
    Time heureFin;
    
    Double luminosite;

    
    public Luminosite (){
        setTable("luminosite");
        setConnection("PostgreSQL");
        setPrefix("CLA");
        setPrimaryKeyName("id_luminosite");
        setFunctionPK("next_val('seq_luminosite'");
        setCountPK(7);
    }


    
    public void setIdLuminosite(String idLuminosite){
        this.idLuminosite = idLuminosite;
    }

    public String getIdLuminosite(){
        return this.idLuminosite;
    }


    public void setDate(Date date){
        this.date = date;
    }

    public Date getDate(){
        return this.date;
    }


    public void setHeureDebut(Time heureDebut){
        this.heureDebut = heureDebut;
    }

    public Time getHeureDebut(){
        return this.heureDebut;
    }


    public void setHeureFin(Time heureFin){
        this.heureFin = heureFin;
    }

    public Time getHeureFin(){
        return this.heureFin;
    }


    public void setLuminosite(Double luminosite){
        this.luminosite = luminosite;
    }

    public Double getLuminosite(){
        return this.luminosite;
    }



}