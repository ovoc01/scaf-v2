package com.noarthedev.panneau.entity;

import com.connection.database.BddObject;


public class Secteur extends BddObject {

    
    String idSecteur;

    
    String libelle;

    
    public Secteur (){
        setTable("secteur");
        setConnection("PostgreSQL");
        setPrefix("CLA");
        setPrimaryKeyName("id_secteur");
        setFunctionPK("next_val('seq_secteur'");
        setCountPK(7);
    }


    
    public void setIdSecteur(String idSecteur){
        this.idSecteur = idSecteur;
    }

    public String getIdSecteur(){
        return this.idSecteur;
    }


    public void setLibelle(String libelle){
        this.libelle = libelle;
    }

    public String getLibelle(){
        return this.libelle;
    }



}