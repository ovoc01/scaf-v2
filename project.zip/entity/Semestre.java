package com.project.entity;

import com.connection.database.BddObject;


public class Semestre extends BddObject {

    
    String idSemestre;

    
    String nom;

    
    public Semestre () throws Exception{
        setTable("semestre");
        setConnection("PostgreSQL");
        setPrefix("SEM");
        setPrimaryKeyName("id_semestre");
        setFunctionPK("next_val('seq_semestre'");
        setCountPK(7);
    }


    
    public void setIdSemestre(String idSemestre){
        this.idSemestre = idSemestre;
    }

    public String getIdSemestre(){
        return this.idSemestre;
    }


    public void setNom(String nom){
        this.nom = nom;
    }

    public String getNom(){
        return this.nom;
    }



}