package com.project.entity;

import com.connection.database.BddObject;


public class Article extends BddObject {

    @ColumnName(value="id")
    String id;

    @ColumnName(value="code")
    String code;
    @ColumnName(value="designation")
    String designation;
    @ColumnName(value="pu")
    Double pu;

    TypeArticle typeArticle;

    UniteArticle uniteArticle;

    
    public Article () throws Exception{
        setTable("article");
        setConnection("PostgreSQL");
        setPrefix("ART");
        setPrimaryKeyName("id");
        setFunctionPK("next_val('seq_article'");
        setCountPK(7);
    }


    
    public void setId(String id){
        this.id = id;
    }

    public String getId(){
        return this.id;
    }


    public void setCode(String code){
        this.code = code;
    }

    public String getCode(){
        return this.code;
    }


    public void setDesignation(String designation){
        this.designation = designation;
    }

    public String getDesignation(){
        return this.designation;
    }


    public void setPu(Double pu){
        this.pu = pu;
    }

    public Double getPu(){
        return this.pu;
    }


    public void setTypeArticle(TypeArticle typeArticle){
        this.typeArticle = typeArticle;
    }

    public TypeArticle getTypeArticle(){
        return this.typeArticle;
    }


    public void setUniteArticle(UniteArticle uniteArticle){
        this.uniteArticle = uniteArticle;
    }

    public UniteArticle getUniteArticle(){
        return this.uniteArticle;
    }



}