package com.project.entity;

import com.connection.database.BddObject;


public class Search extends BddObject {

    @?[id-marks]
    ?[Id]

    
    
    public Search () throws Exception{
        setTable("search");
        setConnection("PostgreSQL");
        setPrefix("SEA");
        setPrimaryKeyName("[primaryKeyColName]");
        setFunctionPK("next_val('seq_search'");
        setCountPK(7);
    }


    
    public void setName(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }


    public void setDescription(String description){
        this.description = description;
    }

    public String getDescription(){
        return this.description;
    }



}