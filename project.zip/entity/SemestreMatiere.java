package com.project.entity;

import com.connection.database.BddObject;


public class SemestreMatiere extends BddObject {

    
    Integer id;

    
    String groupe;
    
    String idOption;

    Matiere matiere;

    Semestre semestre;

    
    public SemestreMatiere () throws Exception{
        setTable("semestre_matiere");
        setConnection("PostgreSQL");
        setPrefix("SEM");
        setPrimaryKeyName("id");
        setFunctionPK("next_val('seq_semestre_matiere'");
        setCountPK(7);
    }


    
    public void setId(Integer id){
        this.id = id;
    }

    public Integer getId(){
        return this.id;
    }


    public void setGroupe(String groupe){
        this.groupe = groupe;
    }

    public String getGroupe(){
        return this.groupe;
    }


    public void setIdOption(String idOption){
        this.idOption = idOption;
    }

    public String getIdOption(){
        return this.idOption;
    }


    public void setMatiere(Matiere matiere){
        this.matiere = matiere;
    }

    public Matiere getMatiere(){
        return this.matiere;
    }


    public void setSemestre(Semestre semestre){
        this.semestre = semestre;
    }

    public Semestre getSemestre(){
        return this.semestre;
    }



}