package com.project.controller;

import com.framework.annontation.*;
import com.framework.ModelView;
import com.project.entity.Search;



public class SearchController extends Search {
    
    

    @restAPI
    @RequestBody
    @url(value = "searchs.do", method = "POST", error = "error.do")
    public void insert() throws Exception{
        this.insert(null);
    }



    @restAPI
    @url(value = "searchs.do",method = "GET", error = "error.do")
    public ModelView findAll() throws Exception{
        ModelView view = new ModelView();
        view.addItem("searchs",this.findAll(null));
        return view;
    }

    @restAPI
    @RequestBody
    @url(value = "searchs.do",method = "PUT", error = "error.do")
    public void update() throws Exception{
        this.update(null);
    }





}