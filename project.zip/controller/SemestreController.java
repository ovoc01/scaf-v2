package com.project.controller;

import com.framework.annontation.*;
import com.framework.ModelView;
import com.project.entity.Semestre;



public class SemestreController extends Semestre {
    
    

    @restAPI
    @RequestBody
    @url(value = "semestres.do", method = "POST", error = "error.do")
    public void insert() throws Exception{
        this.insert(null);
    }



    @restAPI
    @url(value = "semestres.do",method = "GET", error = "error.do")
    public ModelView findAll() throws Exception{
        ModelView view = new ModelView();
        view.addItem("semestres",this.findAll(null));
        return view;
    }

    @restAPI
    @RequestBody
    @url(value = "semestres.do",method = "PUT", error = "error.do")
    public void update() throws Exception{
        this.update(null);
    }





}