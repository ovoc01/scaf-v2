package com.project.controller;

import com.framework.annontation.*;
import com.framework.ModelView;
import com.project.entity.SemestreMatiere;



public class SemestreMatiereController extends SemestreMatiere {
    
    

    @restAPI
    @RequestBody
    @url(value = "semestre_matieres.do", method = "POST", error = "error.do")
    public void insert() throws Exception{
        this.insert(null);
    }



    @restAPI
    @url(value = "semestre_matieres.do",method = "GET", error = "error.do")
    public ModelView findAll() throws Exception{
        ModelView view = new ModelView();
        view.addItem("semestre_matieres",this.findAll(null));
        return view;
    }

    @restAPI
    @RequestBody
    @url(value = "semestre_matieres.do",method = "PUT", error = "error.do")
    public void update() throws Exception{
        this.update(null);
    }





}