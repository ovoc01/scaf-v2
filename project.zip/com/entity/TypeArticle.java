package com.project.entity;

import com.connection.database.BddObject;


public class TypeArticle extends BddObject {

    @ColumnName(value="id")
    String id;

    @ColumnName(value="description")
    String description;

    
    public TypeArticle () throws Exception{
        setTable("type_article");
        setConnection("PostgreSQL");
        setPrefix("TYP");
        setPrimaryKeyName("id");
        setFunctionPK("next_val('seq_type_article'");
        setCountPK(7);
    }


    
    public void setId(String id){
        this.id = id;
    }

    public String getId(){
        return this.id;
    }


    public void setDescription(String description){
        this.description = description;
    }

    public String getDescription(){
        return this.description;
    }



}