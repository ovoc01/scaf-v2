package com.project.entity;

import com.connection.database.BddObject;


public class Fac extends BddObject {

    @ColumnName(value="id")
    Long id;

    
    Facture facture;

    
    public Fac () throws Exception{
        setTable("fac");
        setConnection("PostgreSQL");
        setPrefix("F");
        setPrimaryKeyName("id");
        setFunctionPK("next_val('seq_fac'");
        setCountPK(7);
    }


    
    public void setId(Long id){
        this.id = id;
    }

    public Long getId(){
        return this.id;
    }


    public void setFacture(Facture facture){
        this.facture = facture;
    }

    public Facture getFacture(){
        return this.facture;
    }



}