package com.noarthedev.factures;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturesApplicationTests {

	@Test
	void contextLoads() {
	}

}
