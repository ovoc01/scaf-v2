package com.noarthedev.factures;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacturesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacturesApplication.class, args);
	}

}
