package com.noarthedev.facturesFrame.entity;

import com.connection.database.BddObject;
import java.sql.Date;


public class Facture extends BddObject {

    
    String id;

    
    Date daty;
    
    String designation;
    
    Double etat;
    
    Double montanttotal;

    
    public Facture (){
        setTable("facture");
        setConnection("PostgreSQL");
        setPrefix("FAC");
        setPrimaryKeyName("id");
        setFunctionPK("next_val('seq_facture'");
        setCountPK(7);
    }


    
    public void setDaty(Date daty){
        this.daty = daty;
    }

    public Date getDaty(){
        return this.daty;
    }


    public void setDesignation(String designation){
        this.designation = designation;
    }

    public String getDesignation(){
        return this.designation;
    }


    public void setEtat(Double etat){
        this.etat = etat;
    }

    public Double getEtat(){
        return this.etat;
    }


    public void setMontanttotal(Double montanttotal){
        this.montanttotal = montanttotal;
    }

    public Double getMontanttotal(){
        return this.montanttotal;
    }



}