package com.facturesFrame.entity;

import com.connection.database.BddObject;
import java.sql.Date;


public class Facture extends BddObject {

    
    String id;

    
    Date daty;
    
    String designation;
    
    Double etat;
    
    Double montanttotal;

    
    public Facture () throws Exception{
        setTable("facture");
        setConnection("PostgreSQL");
        setPrefix("FAC");
        setPrimaryKeyName("id");
        setFunctionPK("next_val('seq_facture'");
        setCountPK(7);
    }


    
    public void setId(String id){
        this.id = id;
    }

    public String getId(){
        return this.id;
    }


    public void setDaty(Date daty){
        this.daty = daty;
    }

    public Date getDaty(){
        return this.daty;
    }


    public void setDesignation(String designation){
        this.designation = designation;
    }

    public String getDesignation(){
        return this.designation;
    }


    public void setEtat(Double etat){
        this.etat = etat;
    }

    public Double getEtat(){
        return this.etat;
    }


    public void setMontanttotal(Double montanttotal){
        this.montanttotal = montanttotal;
    }

    public Double getMontanttotal(){
        return this.montanttotal;
    }



}