package com.facturesFrame.entity;

import com.connection.database.BddObject;


public class DetailFacture extends BddObject {

    
    String id;

    
    Double quantite;
    
    Double pu;
    
    Double montant;

    Article article;

    Facture facture;

    
    public DetailFacture () throws Exception{
        setTable("detail_facture");
        setConnection("PostgreSQL");
        setPrefix("DET");
        setPrimaryKeyName("id");
        setFunctionPK("next_val('seq_detail_facture'");
        setCountPK(7);
    }


    
    public void setId(String id){
        this.id = id;
    }

    public String getId(){
        return this.id;
    }


    public void setQuantite(Double quantite){
        this.quantite = quantite;
    }

    public Double getQuantite(){
        return this.quantite;
    }


    public void setPu(Double pu){
        this.pu = pu;
    }

    public Double getPu(){
        return this.pu;
    }


    public void setMontant(Double montant){
        this.montant = montant;
    }

    public Double getMontant(){
        return this.montant;
    }


    public void setArticle(Article article){
        this.article = article;
    }

    public Article getArticle(){
        return this.article;
    }


    public void setFacture(Facture facture){
        this.facture = facture;
    }

    public Facture getFacture(){
        return this.facture;
    }



}