package com.noarthedev.facturesFrame.entity;

import com.connection.database.BddObject;


public class TypeArticle extends BddObject {

    
    String id;

    
    String description;

    
    public TypeArticle (){
        setTable("type_article");
        setConnection("PostgreSQL");
        setPrefix("TYP");
        setPrimaryKeyName("id");
        setFunctionPK("next_val('seq_type_article'");
        setCountPK(7);
    }


    
    public void setDescription(String description){
        this.description = description;
    }

    public String getDescription(){
        return this.description;
    }



}