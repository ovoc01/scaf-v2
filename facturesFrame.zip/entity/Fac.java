package com.noarthedev.facturesFrame.entity;

import com.connection.database.BddObject;


public class Fac extends BddObject {

    
    Long id;

    
    Facture facture;

    
    public Fac (){
        setTable("fac");
        setConnection("PostgreSQL");
        setPrefix("F");
        setPrimaryKeyName("id");
        setFunctionPK("next_val('seq_fac'");
        setCountPK(7);
    }


    
    public void setFacture(Facture facture){
        this.facture = facture;
    }

    public Facture getFacture(){
        return this.facture;
    }



}