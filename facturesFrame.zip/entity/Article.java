package com.noarthedev.facturesFrame.entity;

import com.connection.database.BddObject;


public class Article extends BddObject {

    
    String id;

    
    String code;
    
    String designation;
    
    Double pu;

    TypeArticle typeArticle;

    UniteArticle uniteArticle;

    
    public Article (){
        setTable("article");
        setConnection("PostgreSQL");
        setPrefix("ART");
        setPrimaryKeyName("id");
        setFunctionPK("next_val('seq_article'");
        setCountPK(7);
    }


    
    public void setCode(String code){
        this.code = code;
    }

    public String getCode(){
        return this.code;
    }


    public void setDesignation(String designation){
        this.designation = designation;
    }

    public String getDesignation(){
        return this.designation;
    }


    public void setPu(Double pu){
        this.pu = pu;
    }

    public Double getPu(){
        return this.pu;
    }


    public void setTypeArticle(TypeArticle typeArticle){
        this.typeArticle = typeArticle;
    }

    public TypeArticle getTypeArticle(){
        return this.typeArticle;
    }


    public void setUniteArticle(UniteArticle uniteArticle){
        this.uniteArticle = uniteArticle;
    }

    public UniteArticle getUniteArticle(){
        return this.uniteArticle;
    }



}