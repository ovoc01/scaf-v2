package com.noarthedev.facturesFrame.controller;

import com.framework.annotation.*;
import com.framework.ModelView;
import com.noarthedev.facturesFrame.entity.TypeArticle;



public class TypeArticleController extends TypeArticle {
    
    

    @restAPI
    @RequestBody
    @url(value = "type_articles.do", method = "POST", error = "error.do")
    public void insert() throws Exception{
        this.insert(null);
    }



    @restAPI
    @url(value = "type_articles.do",method = "GET", error = "error.do")
    public ModelView findAll() throws Exception{
        ModelView view = new ModelView();
        view.addItem("type_articles",this.findAll(null));
        return view;
    }

    @restAPI
    @RequestBody
    @url(value = "type_articles.do",method = "PUT", error = "error.do")
    public void update() throws Exception{
        this.update(null);
    }





}