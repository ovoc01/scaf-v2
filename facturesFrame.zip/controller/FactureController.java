package com.facturesFrame.controller;

import com.framework.annontation.*;
import com.framework.ModelView;
import com.facturesFrame.entity.Facture;



public class FactureController extends Facture {
    
    

    @restAPI
    @RequestBody
    @url(value = "factures.do", method = "POST", error = "error.do")
    public void insert() throws Exception{
        this.insert(null);
    }



    @restAPI
    @url(value = "factures.do",method = "GET", error = "error.do")
    public ModelView findAll() throws Exception{
        ModelView view = new ModelView();
        view.addItem("factures",this.findAll(null));
        return view;
    }

    @restAPI
    @RequestBody
    @url(value = "factures.do",method = "PUT", error = "error.do")
    public void update() throws Exception{
        this.update(null);
    }





}