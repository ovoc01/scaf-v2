package com.noarthedev.facturesFrame.controller;

import com.framework.annotation.*;
import com.framework.ModelView;
import com.noarthedev.facturesFrame.entity.DetailFacture;



public class DetailFactureController extends DetailFacture {
    
    

    @restAPI
    @RequestBody
    @url(value = "detail_factures.do", method = "POST", error = "error.do")
    public void insert() throws Exception{
        this.insert(null);
    }



    @restAPI
    @url(value = "detail_factures.do",method = "GET", error = "error.do")
    public ModelView findAll() throws Exception{
        ModelView view = new ModelView();
        view.addItem("detail_factures",this.findAll(null));
        return view;
    }

    @restAPI
    @RequestBody
    @url(value = "detail_factures.do",method = "PUT", error = "error.do")
    public void update() throws Exception{
        this.update(null);
    }





}